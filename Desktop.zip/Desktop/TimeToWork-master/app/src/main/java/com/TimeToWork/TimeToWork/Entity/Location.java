package com.TimeToWork.TimeToWork.Entity;

/**
 * Created by MelvinTanChunKeat on 3/8/2018.
 */

public class Location {
    private String location;

    public Location(String location){
        this.location = location;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
