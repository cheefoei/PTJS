package com.TimeToWork.TimeToWork.Entity;

/**
 * Created by MelvinTanChunKeat on 3/8/2018.
 */

public class Job {
    private String job;

    public Job(String job){
        this.job = job;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }
}
